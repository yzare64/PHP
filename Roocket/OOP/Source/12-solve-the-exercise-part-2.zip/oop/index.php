<?php

class User {
    public $id;
    public $name;
    public $username;
    public $email;
    public $is_admin;
    public $is_active;
    public $password;

    public $users = [
        [
            'id' => 1,
            'name' => 'hesam mousavi',
            'username' => 'hesam',
            'email' => 'hesam@gmail.com',
            'is_admin' => true,
            'is_active' => true,
            'password' => '1234567'
        ],
        [
            'id' => 2,
            'name' => 'reza mohammadi',
            'username' => 'reza',
            'email' => 'reza@gmail.com',
            'is_admin' => false,
            'is_active' => false,
            'password' => '1234'
        ]
    ];

    /**
     * @param $userId
     * @return array
     */
    public function find($userId)
    {
        $data = $this->findUserById($userId);

        $user = array_shift($data);

        is_null($user) ?: $this->passArrayToUserField(
            $user
        );

        return $user;
    }

    public function save()
    {
        // validation data
        $lasUser = end($this->users);

        $user = [
            'id' => $lasUser ? $lasUser['id'] + 1 : 1,
            'name' => $this->name,
            'user' => $this->username,
            'email' => $this->email,
            'password' => $this->password,
            'is_admin' => $this->is_admin,
            'is_active' => $this->is_active
        ];

        array_push($this->users , $user);

        return true;
        // store user data in users
    }

    /**
     * @return bool
     */
    public function isAdmin()
    {
        return $this->is_admin === true;
    }

    public function isActive()
    {
        return $this->is_active === true;
    }

    /**
     * @param $userId
     * @return array[]
     */
    public function findUserById($userId)
    {
        return array_filter($this->users, function ($user) use ($userId) {
            return $user['id'] == $userId;
        });
    }

    /**
     * @param array $user
     */
    public function passArrayToUserField(array $user)
    {
        foreach ($user as $key => $value) {
            if (property_exists($this, $key)) {
                $this->{$key} = $value;
            }
        }
    }
}

// TODO User class
  // method find($userId) | save()


$user = new User();
$user->name = 'fatemeh';
$user->username = 'fatemeh111';
$user->email = 'fatemeh@gmail.com';
$user->password = '55555';
$user->is_admin = false;
$user->is_active = false;


//$result = $user->find(2);
$user->save();
var_dump($user->users);